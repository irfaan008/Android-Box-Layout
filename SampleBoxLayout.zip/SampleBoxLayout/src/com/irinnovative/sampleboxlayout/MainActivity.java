package com.irinnovative.sampleboxlayout;

import com.irinnovative.boxlayout.BoxLayout;

import android.os.Bundle;
import android.app.Activity;

public class MainActivity extends Activity {
	private BoxLayout box;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		box = (BoxLayout) findViewById(R.id.boxAboutUs);
		box.setTitle(R.drawable.backup_contact, "Contact Backup", 0);
		box.setRow1("Last backup", "10-Dec-2013");
		box.setRow2("Contact us:", "irfaan.aa@gmail.com");
		box.setRow3(
				"We recommend to take backup of your contact on weekly basis.",
				null);
		box.setRow4("Click to Backup", "Backup Now");
		box.showDevider(true);
	}

	@Override
	protected void onResume() {
		super.onResume();

	}

}
